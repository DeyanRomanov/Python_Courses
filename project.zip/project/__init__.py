class Hotel:
    pass